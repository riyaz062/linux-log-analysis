# Linux Log Analysis Project

This project demonstrates basic SOC-level log analysis using Linux commands.
