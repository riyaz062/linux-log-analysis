## Linux Authentication Log Analysis

Objective:
Analyze authentication logs to detect suspicious login attempts.

Tools:
Kali Linux, cat, grep, head, piping

Analysis:
Multiple failed login attempts detected.
Repeated IP: 192.168.1.10

Conclusion:
Possible brute-force attack observed.
